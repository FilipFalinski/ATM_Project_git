





-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE Accounts
   (	
		AccountID integer NOT NULL UNIQUE,
		Pin Numeric NOT NULL,
		 PRIMARY KEY (AccountID)
  ) ;
  
  CREATE TABLE Transactions
   (	
   AccountID integer NOT NULL UNIQUE,
   Lodge int NOT NULL ,
   Amount int NOT NULL,
   Deposit int NOT NULL,
   PRIMARY KEY (Amount),
   FOREIGN KEY (AccountID) REFERENCES  Accounts(AccountID))
   ;
  

/*INSERT INTO Accounts (AccountID,  Pin) values (1, 1234)
 INSERT INTO Accounts (AccountID, Pin) values (2, 4568)
INSERT INTO Accounts (AccountID,  Pin) values (3, 3876)*/

SELECT * FROM Accounts;

	
  