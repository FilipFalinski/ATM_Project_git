using ATM_Project;
using System;
using Xunit;

namespace ATMtest
{
    public class UnitTest1
    {


        [Fact]
        public void testDeposit()

        {


            decimal balance = 110;
            decimal depositAmount = 100;
            decimal expected = balance + depositAmount;

            Account account = new Account("Paul Kerins", 1234, balance);
            account.Deposit(depositAmount);

            decimal actual = balance + depositAmount;
            Assert.True(actual == expected, "Account is Correct");
        }






        [Fact]
        public void testWithdraw()
        {

            decimal balance = 110;
            decimal withdrawalAmount = 100;
            decimal expected = balance - withdrawalAmount;
            Account account = new Account("Paul Kerins", 1234, balance);

            account.Withdrawl(withdrawalAmount);

            decimal actual = balance - withdrawalAmount;
            Assert.True(actual == expected, "Account is Correct");


        }
    }
}
