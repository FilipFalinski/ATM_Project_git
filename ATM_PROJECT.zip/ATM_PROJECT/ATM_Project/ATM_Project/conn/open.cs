﻿namespace conn
{
    internal class open
    {
    }
}