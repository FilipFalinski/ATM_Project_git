﻿using System;
using System.Collections.Generic;
using System.Security.Principal;
using System.Text;

namespace ATM_Project
{
    public class AccountRepositoryInMemory : IAccountRepository
    {
        readonly Dictionary<string, Account> data = new Dictionary<string, Account>();

        public void Save(Account account)
        {
            data[account.GetAccountId()] = account;
        }

        public Account Load(String AccountID)
        {
         
            
            
            return data[AccountID];
            
        }

       
        internal Account Load(object text)
        {

            
            throw new NotImplementedException();
             
        }
    }
}
   