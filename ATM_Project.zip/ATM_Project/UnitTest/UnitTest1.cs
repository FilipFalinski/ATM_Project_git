﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            // Arrange
            ATM_Project.Account account = new ATM_Project.Account(1234, 1000, 12345678);
            int expected = 2000;

            // Act
            account.lodge(1000);
            int actual = account.getBalance();

            // Assert
            Assert.AreEqual(expected, actual);


        }
    }
}
