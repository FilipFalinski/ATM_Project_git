﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM_Project
{

    public partial class Withdraw : Form
    {

        Account_Managment parent;

        public Withdraw()
        {
            InitializeComponent();
             
        }

        public Withdraw(Account_Managment account_Managment)
        {
        }

        private void Twenty_btn_Click(object sender, EventArgs e)
        {
            int amount = 20;
            int balance = 1000;
            int newBalance = balance - amount;
            MessageBox.Show("Your new balance is " + newBalance, "Balance", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void fifty_btn_Click(object sender, EventArgs e)
        {
            int amount = 50;
            int balance = 1000;
            int newBalance = balance - amount;
            MessageBox.Show("Your new balance is " + newBalance, "Balance", MessageBoxButtons.OK, MessageBoxIcon.Information);
            
        }

        private void hundred_btn_Click(object sender, EventArgs e)
        {
            int amount = 100;
            int balance = 1000;
            int newBalance = balance - amount;
            MessageBox.Show("Your new balance is " + newBalance, "Balance", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void twoHundred_btn_Click(object sender, EventArgs e)
        {
            int amount = 200;
            int balance = 1000;
            int newBalance = balance - amount;
            MessageBox.Show("Your new balance is " + newBalance, "Balance", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void fiveHundred_btn_Click(object sender, EventArgs e)
        {
            int amount = 500;
            int balance = 1000;
            int newBalance = balance - amount;
            MessageBox.Show("Your new balance is " + newBalance, "Balance", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void grnad_btn_Click(object sender, EventArgs e)
        {
            int amount = 1000;
            int balance = 1000;
            int newBalance = balance - amount;
            MessageBox.Show("Your new balance is " + newBalance, "Balance", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Amount_txt_TextChanged(object sender, EventArgs e)
        {
            int amount = Convert.ToInt32(Amount_txt.Text);
            int balance = 1000;
            int newBalance = balance - amount;
            MessageBox.Show("Your new balance is " + newBalance, "Balance", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Cancel_btn_Click(object sender, EventArgs e)
        {
            this.Close();
            parent.Visible = true;
        }

        private void Confirm_btn_Click(object sender, EventArgs e)
        {
             

        }
    }
}
