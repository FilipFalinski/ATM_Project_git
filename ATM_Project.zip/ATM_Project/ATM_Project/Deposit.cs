﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ATM_Project
{
    public partial class Deposit : Form
    {
        Account_Managment parent;
        public Deposit()
        {
            InitializeComponent();
        }

        public Deposit(Account_Managment account_Managment)
        {
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
             
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void ten_txt_TextChanged(object sender, EventArgs e)
        {

        }

        private void twenty_txt_TextChanged(object sender, EventArgs e)
        {

        }

        private void fifty_txt_TextChanged(object sender, EventArgs e)
        {

        }

        private void hundred_txt_TextChanged(object sender, EventArgs e)
        {

        }

        private void twoHun_txt_TextChanged(object sender, EventArgs e)
        {

        }

        private void fiveHun_txt_TextChanged(object sender, EventArgs e)
        {

        }

        private void total_txt_TextChanged(object sender, EventArgs e)
        {

        }

        private void Confirm_btn_Click(object sender, EventArgs e)
        {

        }

        private void cancel_btn_Click(object sender, EventArgs e)
        {

        }
    }
}
