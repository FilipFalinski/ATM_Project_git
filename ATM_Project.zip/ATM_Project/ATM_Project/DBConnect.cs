﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATM_Project
{
    internal class DBConnect
    { //use this connection string when using your laptop
        //public const String oradb = "Data Source = localhost/orcl; User Id = system; Password = itt12345;";
        //use this connection string when using your laptop
        //public const String oradb = "Data Source = localhost/orcl; User Id = C##User1; Password = 123456;";

        //use this connection string on ITT system
        //public const String oradb = "Data Source = oracle/orcl; User Id = Leccw; Password = 123456;";

        //Connection string for personal laptop (yours may be different)
        //public const String oradb = "Data Source = 127.0.0.1:1521/xepdb1; User Id = cafe; Password = cafe;";
    }
}
